import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

public class ChooseEvents {
	//private final static int userLocation = 4; //To calculate Manhattan distance from user and events.
	private final static int minCoordinateLimit = -10;
	private final static int maxCoordinateLimit = 10;
	private static int leftCoordinate;
	private static int rightCoordinate;
	public static ArrayList<LocationEvents> locations = new ArrayList<LocationEvents>();
	public static ArrayList<Event> events = new ArrayList<Event>();
	private static final int maxEvents = 10;
	private static final int THRESHOLDDISTANCE = 8;
	public static void main(String[] args) {
		ChooseEvents chooseEventsObject = new ChooseEvents();
//		ce.createMockUpLocations();
		chooseEventsObject.createMockUpEvents();
		System.out.println("Please Choose Coordinates < from 1 - 10> example 2,4:");
		Scanner inputScanner = new Scanner(System.in);
		leftCoordinate = inputScanner.nextInt();
		rightCoordinate = inputScanner.nextInt();
		System.out.println("Left Coordinate Entered : "+chooseEventsObject.leftCoordinate+"\n");
		System.out.println("Right Coordinate Entered : "+chooseEventsObject.rightCoordinate+"\n");
		
//		boolean exists = ce.CheckIfCoordinatesExists();
//		System.out.println(exists);
		chooseEventsObject.listEventIds();
	}
//	private void createMockUpLocations(){
//		//Mock up Set Events and locations
//		for(int i = minCoordinateLimit; i <= maxCoordinateLimit; i++){
//			for(int j = minCoordinateLimit; j <= maxCoordinateLimit; j++  ){
//				Location l = new Location();
//				l.locationId = i;
//				l.left = i;
//				l.right = j;
//				locations.add(l);
//			}
//		}
//	}
	
	private void createMockUpEvents(){
		for(int i = 000;i< maxEvents; i++){
			Event e = new Event();
			i++;
			e.eventId = i;
			e.left = getRandomNumberWithinLimits(maxCoordinateLimit);
			e.right = getRandomNumberWithinLimits(maxCoordinateLimit);
			e.prize = getRandomNumberWithinLimits(95);
			events.add(e);
		}
		
	}
	private int calculateDistance(int x1, int x0, int y1, int y0){
		int distance = Math.abs(x1-x0) + Math.abs(y1-y0); 
		return distance;
	}
	
	private int getRandomNumberWithinLimits(int range){
		Random rand =new Random();
		int randNum = rand.nextInt(range);
		return randNum;
	}
//	private boolean CheckIfCoordinatesExists(){
//		for(int i =0; i< locations.size(); i++){
//			if(locations.get(i).left == leftCoordinate && locations.get(i).right == rightCoordinate){
//				return true;
//			}
//		}
//		return false;
//	}
//	
	private void listEventIds(){
		//ArrayList<Integer> temp = new ArrayList<Integer>();
		ArrayList<LocationEvents> locEvents = new ArrayList<LocationEvents>();
		for(int i =0; i< events.size(); i++){
			int mahattanDist = calculateDistance(events.get(i).left,leftCoordinate,events.get(i).right, rightCoordinate);
			if( mahattanDist <= THRESHOLDDISTANCE ){
				LocationEvents le = new LocationEvents();
				le.eventId = events.get(i).eventId;
				le.distance = mahattanDist;
				le.prize = events.get(i).prize;
				locEvents.add(le);
			}
			Collections.sort(locEvents, LocationEvents.prizeComparator);
			
		}
		System.out.println("EventIds are : ");
		for(int i =0; i< locEvents.size(); i++){
			System.out.println(" Event 00"+locEvents.get(i).eventId+" - $"+locEvents.get(i).prize +", Distance "+locEvents.get(i).distance+"\n");
		}
	}
}
