import java.util.Comparator;

public class LocationEvents {
		int distance;
		//ArrayList<Event> events = new ArrayList<Event>();
		int eventId;
		float prize;
		public int getDistance() {
			return distance;
		}

		public void setDistance(int distance) {
			this.distance = distance;
		}

		public int getEventId() {
			return eventId;
		}

		public void setEventId(int eventId) {
			this.eventId = eventId;
		}

		public void setPrize(float prize) {
			this.prize = prize;
		}

		public float getPrize() {
			return this.prize;
		}

		public static Comparator<LocationEvents> prizeComparator = new Comparator<LocationEvents>() {

			public int compare(LocationEvents e1, LocationEvents e2) {
				float prize1 =  e1.getPrize();
				float prize2 =  e2.getPrize();

				//ascending order
				return (int)(prize1-prize2);

	    }};
}

